package com.aaa.lee.repast.mapper;

import com.aaa.lee.repast.model.LoginLog;
import tk.mybatis.mapper.common.Mapper;

public interface LoginLogMapper extends Mapper<LoginLog> {
}